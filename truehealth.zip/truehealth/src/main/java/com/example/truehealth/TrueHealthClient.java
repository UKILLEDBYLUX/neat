package com.example.truehealth;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class TrueHealthClient implements ClientModInitializer {
    /** How far (in blocks) we look for a target. */
    private static final double RANGE = 64.0;

    private static final int BAR_WIDTH = 160;
    private static final int BAR_HEIGHT = 10;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(TrueHealthClient::render);
    }

    private static LivingEntity findTarget(MinecraftClient client, float delta) {
        Entity cam = client.getCameraEntity();
        if (cam == null || client.world == null) return null;

        Vec3d start = cam.getCameraPosVec(delta);
        Vec3d dir = cam.getRotationVec(delta);
        Vec3d end = start.add(dir.multiply(RANGE));

        // Don't "see" through walls: limit the entity search by the first block hit.
        HitResult blockHit = cam.raycast(RANGE, delta, false);
        double maxDistSq = blockHit.getType() == HitResult.Type.MISS
                ? RANGE * RANGE
                : blockHit.getPos().squaredDistanceTo(start);

        Box box = cam.getBoundingBox().stretch(dir.multiply(RANGE)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(
                cam, start, end, box,
                e -> !e.isSpectator() && e.canHit(),
                maxDistSq);

        if (hit != null && hit.getEntity() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden || client.currentScreen != null) return;

        float delta = tickCounter.getTickDelta(true);
        LivingEntity target = findTarget(client, delta);
        if (target == null) return;

        // getHealth / getAbsorptionAmount are synced tracked data.
        // getMaxHealth reads the attribute, which the server syncs together with
        // any modifiers from held/worn items, so bonus HP is already included.
        float health = target.getHealth();
        float maxHealth = Math.max(target.getMaxHealth(), 0.0001f);
        float absorption = target.getAbsorptionAmount();

        float ratio = MathHelper.clamp(health / maxHealth, 0f, 1f);
        float absRatio = MathHelper.clamp(absorption / maxHealth, 0f, 1f);

        int screenW = ctx.getScaledWindowWidth();
        int x = (screenW - BAR_WIDTH) / 2;
        int y = 20;

        var font = client.textRenderer;

        // Name
        ctx.drawCenteredTextWithShadow(font, target.getDisplayName(), screenW / 2, y - 12, 0xFFFFFFFF);

        // Background
        ctx.fill(x - 1, y - 1, x + BAR_WIDTH + 1, y + BAR_HEIGHT + 1, 0xC0000000);
        ctx.fill(x, y, x + BAR_WIDTH, y + BAR_HEIGHT, 0xFF303030);

        // Health (green -> red)
        int fill = Math.round(BAR_WIDTH * ratio);
        int r = (int) (255 * (1f - ratio));
        int g = (int) (200 * ratio + 55);
        int color = 0xFF000000 | (r << 16) | (g << 8) | 0x30;
        ctx.fill(x, y, x + fill, y + BAR_HEIGHT, color);

        // Absorption (gold strip under the bar)
        if (absorption > 0f) {
            int absFill = Math.round(BAR_WIDTH * absRatio);
            ctx.fill(x, y + BAR_HEIGHT + 2, x + absFill, y + BAR_HEIGHT + 5, 0xFFFFD700);
        }

        // Text: exact numbers
        String label = String.format("%.1f", health);
        if (absorption > 0f) label += String.format(" +%.1f", absorption);
        label += String.format(" / %.1f", target.getMaxHealth());
        ctx.drawCenteredTextWithShadow(font, Text.literal(label), screenW / 2, y + 1, 0xFFFFFFFF);
    }
}
